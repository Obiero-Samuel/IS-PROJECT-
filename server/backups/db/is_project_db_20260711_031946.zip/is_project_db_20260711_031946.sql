--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: authority_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.authority_type AS ENUM (
    'municipal',
    'county',
    'national',
    'ngo'
);


ALTER TYPE public.authority_type OWNER TO postgres;

--
-- Name: escalation_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.escalation_status AS ENUM (
    'pending',
    'acknowledged',
    'resolved',
    'rejected'
);


ALTER TYPE public.escalation_status OWNER TO postgres;

--
-- Name: report_period; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.report_period AS ENUM (
    'monthly',
    'quarterly',
    'annual',
    'weekly'
);


ALTER TYPE public.report_period OWNER TO postgres;

--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_updated_at() OWNER TO postgres;

--
-- Name: sync_status_logs_to_audit_trail(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sync_status_logs_to_audit_trail() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  actor_role_value VARCHAR(20);
BEGIN
  SELECT role INTO actor_role_value FROM users WHERE id = NEW.changed_by;

  INSERT INTO audit_trail (
    report_id,
    actor_user_id,
    actor_role,
    action_type,
    old_status,
    new_status,
    notes,
    metadata,
    source_status_log_id,
    created_at
  )
  VALUES (
    NEW.report_id,
    NEW.changed_by,
    COALESCE(actor_role_value, 'system'),
    CASE WHEN NEW.old_status IS NULL THEN 'report_submitted' ELSE 'status_changed' END,
    NEW.old_status,
    NEW.new_status,
    NEW.notes,
    jsonb_build_object('source', 'status_logs'),
    NEW.id,
    NEW.changed_at
  )
  ON CONFLICT (source_status_log_id) DO NOTHING;

  RETURN NEW;
END;
$$;


ALTER FUNCTION public.sync_status_logs_to_audit_trail() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._migrations (
    id integer NOT NULL,
    filename character varying(255) NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public._migrations OWNER TO postgres;

--
-- Name: _migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._migrations_id_seq OWNER TO postgres;

--
-- Name: _migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._migrations_id_seq OWNED BY public._migrations.id;


--
-- Name: analytics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics (
    id bigint NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    total_reports integer DEFAULT 0 NOT NULL,
    resolved_reports integer DEFAULT 0 NOT NULL,
    pending_reports integer DEFAULT 0 NOT NULL,
    in_progress_reports integer DEFAULT 0 NOT NULL,
    overdue_escalations integer DEFAULT 0 NOT NULL,
    response_rate_pct numeric(6,2) DEFAULT 0 NOT NULL,
    generated_session_id bigint,
    generated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.analytics OWNER TO postgres;

--
-- Name: analytics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.analytics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analytics_id_seq OWNER TO postgres;

--
-- Name: analytics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.analytics_id_seq OWNED BY public.analytics.id;


--
-- Name: audit_trail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_trail (
    id bigint NOT NULL,
    report_id integer,
    actor_user_id integer,
    actor_role character varying(20) DEFAULT 'system'::character varying NOT NULL,
    action_type character varying(60) NOT NULL,
    old_status character varying(50),
    new_status character varying(50),
    notes text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_status_log_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT audit_trail_actor_role_check CHECK (((actor_role)::text = ANY ((ARRAY['resident'::character varying, 'authority'::character varying, 'admin'::character varying, 'system'::character varying])::text[])))
);


ALTER TABLE public.audit_trail OWNER TO postgres;

--
-- Name: audit_trail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_trail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_trail_id_seq OWNER TO postgres;

--
-- Name: audit_trail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_trail_id_seq OWNED BY public.audit_trail.id;


--
-- Name: authorities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authorities (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    type public.authority_type DEFAULT 'municipal'::public.authority_type NOT NULL,
    jurisdiction character varying(255),
    contact_email character varying(255),
    phone character varying(30),
    website character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.authorities OWNER TO postgres;

--
-- Name: TABLE authorities; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.authorities IS 'Civic and government bodies responsible for handling escalated issues';


--
-- Name: COLUMN authorities.type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.authorities.type IS 'Classification: municipal, county, national, or ngo';


--
-- Name: COLUMN authorities.jurisdiction; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.authorities.jurisdiction IS 'Geographic or administrative area the authority covers';


--
-- Name: COLUMN authorities.is_active; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.authorities.is_active IS 'Soft-delete flag; FALSE hides the authority from public listings';


--
-- Name: authorities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.authorities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.authorities_id_seq OWNER TO postgres;

--
-- Name: authorities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.authorities_id_seq OWNED BY public.authorities.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: category_authority_map; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category_authority_map (
    category_id integer NOT NULL,
    authority_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    response_deadline_days integer DEFAULT 7 NOT NULL
);


ALTER TABLE public.category_authority_map OWNER TO postgres;

--
-- Name: TABLE category_authority_map; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.category_authority_map IS 'Maps issue categories to the authorities responsible for them';


--
-- Name: escalations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.escalations (
    id integer NOT NULL,
    report_id integer NOT NULL,
    authority_id integer NOT NULL,
    escalated_by integer NOT NULL,
    reason text NOT NULL,
    status public.escalation_status DEFAULT 'pending'::public.escalation_status NOT NULL,
    authority_notes text,
    is_overdue boolean DEFAULT false NOT NULL,
    escalated_at timestamp with time zone DEFAULT now() NOT NULL,
    acknowledged_at timestamp with time zone,
    resolved_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.escalations OWNER TO postgres;

--
-- Name: TABLE escalations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.escalations IS 'Records of reports formally escalated to governing authorities';


--
-- Name: COLUMN escalations.reason; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.escalations.reason IS 'Explanation of why the report was escalated';


--
-- Name: COLUMN escalations.authority_notes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.escalations.authority_notes IS 'Official response or notes provided by the receiving authority';


--
-- Name: COLUMN escalations.is_overdue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.escalations.is_overdue IS 'Set TRUE by cron when escalation is pending >7 days without acknowledgement';


--
-- Name: COLUMN escalations.acknowledged_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.escalations.acknowledged_at IS 'Timestamp when the authority confirmed receipt';


--
-- Name: COLUMN escalations.resolved_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.escalations.resolved_at IS 'Timestamp when the authority marked the escalation resolved';


--
-- Name: escalations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.escalations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.escalations_id_seq OWNER TO postgres;

--
-- Name: escalations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.escalations_id_seq OWNED BY public.escalations.id;


--
-- Name: reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports (
    id integer NOT NULL,
    user_id integer NOT NULL,
    category_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    latitude numeric(9,6),
    longitude numeric(9,6),
    location_address character varying(255),
    status character varying(20) DEFAULT 'pending'::character varying,
    media_url character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    tracking_number character varying(20),
    ward_id integer,
    closed_by_admin boolean DEFAULT false NOT NULL,
    admin_override_notes text,
    closed_at timestamp with time zone,
    resident_deleted_at timestamp with time zone,
    resident_deleted_by integer,
    CONSTRAINT reports_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'in-progress'::character varying, 'resolved'::character varying])::text[])))
);


ALTER TABLE public.reports OWNER TO postgres;

--
-- Name: COLUMN reports.ward_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.reports.ward_id IS 'The ward where the issue was reported';


--
-- Name: reports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reports_id_seq OWNER TO postgres;

--
-- Name: reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reports_id_seq OWNED BY public.reports.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id bigint NOT NULL,
    trigger_name character varying(80) NOT NULL,
    triggered_by character varying(20) NOT NULL,
    triggered_by_user_id integer,
    status character varying(20) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    records_processed integer DEFAULT 0 NOT NULL,
    error_message text,
    CONSTRAINT sessions_status_check CHECK (((status)::text = ANY ((ARRAY['running'::character varying, 'completed'::character varying, 'failed'::character varying])::text[]))),
    CONSTRAINT sessions_triggered_by_check CHECK (((triggered_by)::text = ANY ((ARRAY['system'::character varying, 'admin'::character varying, 'officer'::character varying])::text[])))
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sessions_id_seq OWNER TO postgres;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: status_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status_logs (
    id integer NOT NULL,
    report_id integer NOT NULL,
    changed_by integer NOT NULL,
    old_status character varying(50),
    new_status character varying(50) NOT NULL,
    notes text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.status_logs OWNER TO postgres;

--
-- Name: TABLE status_logs; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.status_logs IS 'Append-only audit log of every status change made to a report';


--
-- Name: COLUMN status_logs.old_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.status_logs.old_status IS 'Status before change; NULL = initial creation event';


--
-- Name: COLUMN status_logs.new_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.status_logs.new_status IS 'Status after the change';


--
-- Name: COLUMN status_logs.notes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.status_logs.notes IS 'Optional reason or context for the status transition';


--
-- Name: status_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.status_logs_id_seq OWNER TO postgres;

--
-- Name: status_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_logs_id_seq OWNED BY public.status_logs.id;


--
-- Name: summary_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.summary_reports (
    id integer NOT NULL,
    authority_id integer NOT NULL,
    ward_id integer,
    report_period public.report_period DEFAULT 'monthly'::public.report_period NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    total_issues integer DEFAULT 0 NOT NULL,
    open_issues integer DEFAULT 0 NOT NULL,
    resolved_issues integer DEFAULT 0 NOT NULL,
    pending_issues integer DEFAULT 0 NOT NULL,
    escalated_issues integer DEFAULT 0 NOT NULL,
    avg_resolution_days numeric(6,2),
    top_category character varying(100),
    report_notes text,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    report_file_url text,
    report_file_type character varying(30)
);


ALTER TABLE public.summary_reports OWNER TO postgres;

--
-- Name: TABLE summary_reports; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.summary_reports IS 'Pre-aggregated periodic reports for authorities and wards';


--
-- Name: COLUMN summary_reports.ward_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.summary_reports.ward_id IS 'NULL means report covers entire jurisdiction';


--
-- Name: COLUMN summary_reports.period_start; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.summary_reports.period_start IS 'Inclusive start date';


--
-- Name: COLUMN summary_reports.period_end; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.summary_reports.period_end IS 'Inclusive end date';


--
-- Name: COLUMN summary_reports.avg_resolution_days; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.summary_reports.avg_resolution_days IS 'Mean calendar days from creation to resolution';


--
-- Name: COLUMN summary_reports.top_category; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.summary_reports.top_category IS 'Most frequently reported category in period';


--
-- Name: summary_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.summary_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.summary_reports_id_seq OWNER TO postgres;

--
-- Name: summary_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.summary_reports_id_seq OWNED BY public.summary_reports.id;


--
-- Name: upvotes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.upvotes (
    user_id integer NOT NULL,
    report_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.upvotes OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'resident'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ward_id integer,
    is_email_verified boolean DEFAULT false NOT NULL,
    email_verification_otp_hash character varying(255),
    email_verification_otp_expires_at timestamp with time zone,
    email_verified_at timestamp with time zone,
    full_name character varying(120),
    phone_number character varying(30),
    date_of_birth date,
    residence character varying(255),
    profile_photo_url text,
    bio character varying(500),
    profile_edit_count integer DEFAULT 0 NOT NULL,
    authority_id integer,
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp with time zone,
    deactivated_at timestamp with time zone,
    deactivation_reason text,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['resident'::character varying, 'authority'::character varying, 'admin'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: wards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wards (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50),
    county character varying(100) NOT NULL,
    constituency character varying(100),
    authority_id integer,
    latitude numeric(9,6),
    longitude numeric(9,6),
    population integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.wards OWNER TO postgres;

--
-- Name: TABLE wards; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.wards IS 'Administrative ward units for geographic scoping of issues';


--
-- Name: COLUMN wards.code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.wards.code IS 'Official government ward code (e.g. NRB-001)';


--
-- Name: COLUMN wards.authority_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.wards.authority_id IS 'Primary authority responsible for this ward';


--
-- Name: COLUMN wards.latitude; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.wards.latitude IS 'Ward centroid latitude for map visualisation';


--
-- Name: wards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wards_id_seq OWNER TO postgres;

--
-- Name: wards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wards_id_seq OWNED BY public.wards.id;


--
-- Name: _migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._migrations ALTER COLUMN id SET DEFAULT nextval('public._migrations_id_seq'::regclass);


--
-- Name: analytics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics ALTER COLUMN id SET DEFAULT nextval('public.analytics_id_seq'::regclass);


--
-- Name: audit_trail id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_trail ALTER COLUMN id SET DEFAULT nextval('public.audit_trail_id_seq'::regclass);


--
-- Name: authorities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authorities ALTER COLUMN id SET DEFAULT nextval('public.authorities_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: escalations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.escalations ALTER COLUMN id SET DEFAULT nextval('public.escalations_id_seq'::regclass);


--
-- Name: reports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports ALTER COLUMN id SET DEFAULT nextval('public.reports_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: status_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_logs ALTER COLUMN id SET DEFAULT nextval('public.status_logs_id_seq'::regclass);


--
-- Name: summary_reports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.summary_reports ALTER COLUMN id SET DEFAULT nextval('public.summary_reports_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: wards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wards ALTER COLUMN id SET DEFAULT nextval('public.wards_id_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._migrations (id, filename, applied_at) FROM stdin;
1	006_create_authorities.sql	2026-06-29 18:21:30.01874+03
2	007_create_wards.sql	2026-06-29 18:21:30.049329+03
3	013_add_user_email_verification_and_ward.sql	2026-06-29 18:21:37.751743+03
4	011_seed_nairobi_west_wards.sql	2026-06-29 18:58:51.897152+03
5	008_create_escalations.sql	2026-06-30 14:53:31.304204+03
6	009_create_status_logs.sql	2026-06-30 14:53:31.35623+03
7	010_create_summary_reports.sql	2026-06-30 14:53:31.379024+03
8	014_add_user_profile_fields.sql	2026-06-30 14:53:31.394147+03
9	015_create_flow_contract_tables.sql	2026-06-30 14:53:31.478961+03
10	016_add_officer_admin_dashboard_contract.sql	2026-07-01 14:55:37.131498+03
11	017_add_weekly_report_period.sql	2026-07-01 15:45:29.38589+03
12	006_seed_authorities.sql	2026-07-04 12:14:46.067395+03
13	007_seed_wards.sql	2026-07-04 12:14:46.082038+03
14	012_seed_categories.sql	2026-07-04 12:15:23.332296+03
15	008_seed_escalations.sql	2026-07-04 12:18:17.299245+03
16	009_seed_status_logs.sql	2026-07-04 12:18:17.311645+03
17	010_seed_summary_reports.sql	2026-07-04 12:19:22.514077+03
18	018_add_resident_report_soft_delete.sql	2026-07-04 13:20:04.283249+03
19	013_seed_category_authority_map.sql	2026-07-09 13:43:45.682892+03
\.


--
-- Data for Name: analytics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics (id, period_start, period_end, total_reports, resolved_reports, pending_reports, in_progress_reports, overdue_escalations, response_rate_pct, generated_session_id, generated_at) FROM stdin;
1	2026-06-30	2026-07-06	1	1	0	0	0	100.00	1	2026-07-06 06:00:00.469256+03
\.


--
-- Data for Name: audit_trail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_trail (id, report_id, actor_user_id, actor_role, action_type, old_status, new_status, notes, metadata, source_status_log_id, created_at) FROM stdin;
1	1	8	resident	report_submitted	\N	pending	\N	{"module": "Report Submission", "ward_id": 42, "category_id": 4, "tracking_number": "CP-20260704-26BA"}	\N	2026-07-04 12:57:27.798926+03
2	\N	8	resident	resident_report_deleted	\N	\N	Resident deleted own report.	{"module": "Resident Reports", "report_id": 1, "deleted_at": "2026-07-04T10:25:04.958Z", "tracking_number": "CP-20260704-26BA"}	\N	2026-07-04 13:25:04.987468+03
3	2	10	resident	report_submitted	\N	pending	\N	{"module": "Report Submission", "ward_id": 44, "category_id": 2, "tracking_number": "CP-20260704-86BF"}	\N	2026-07-04 18:05:17.626138+03
4	2	6	admin	status_changed	pending	resolved	Admin override close: under review	{"source": "status_logs"}	1	2026-07-04 18:08:53.009183+03
5	2	6	admin	admin_override_closed	pending	resolved	under review	{"module": "Admin Reports Management", "closed_by_admin": true}	\N	2026-07-04 18:08:53.074798+03
6	3	8	resident	report_submitted	\N	pending	\N	{"module": "Report Submission", "ward_id": 42, "category_id": 1, "tracking_number": "CP-20260709-764C"}	\N	2026-07-09 09:36:31.138134+03
7	\N	8	resident	resident_report_deleted	\N	\N	Resident deleted own report.	{"module": "Resident Reports", "report_id": 3, "deleted_at": "2026-07-09T06:37:03.936Z", "tracking_number": "CP-20260709-764C"}	\N	2026-07-09 09:37:03.95319+03
8	4	8	resident	report_submitted	\N	pending	\N	{"module": "Report Submission", "ward_id": 42, "category_id": 2, "tracking_number": "CP-20260709-9061"}	\N	2026-07-09 09:41:27.055861+03
9	\N	8	resident	resident_report_deleted	\N	\N	Resident deleted own report.	{"module": "Resident Reports", "report_id": 4, "deleted_at": "2026-07-09T06:41:50.885Z", "tracking_number": "CP-20260709-9061"}	\N	2026-07-09 09:41:50.916296+03
10	5	8	resident	report_submitted	\N	pending	\N	{"module": "Report Submission", "ward_id": 42, "category_id": 2, "tracking_number": "CP-20260709-8D96"}	\N	2026-07-09 09:43:53.850323+03
11	6	10	resident	report_submitted	\N	pending	\N	{"module": "Report Submission", "ward_id": 44, "category_id": 1, "tracking_number": "CP-20260709-6F8D"}	\N	2026-07-09 09:52:38.494691+03
12	7	8	resident	report_submitted	\N	pending	\N	{"module": "Report Submission", "ward_id": 42, "category_id": 1, "tracking_number": "CP-20260709-0169"}	\N	2026-07-09 10:15:54.8432+03
13	\N	6	admin	admin_category_authority_mapping_saved	\N	\N	\N	{"module": "Admin Deadline Management", "category_id": 1, "authority_id": 15, "category_name": "Roads & Potholes", "authority_name": "Kenya Power & Lighting Company", "response_deadline_days": 7}	\N	2026-07-09 13:16:48.832759+03
14	\N	6	admin	admin_weekly_export_generated	\N	\N	Generated CSV weekly export	{"format": "csv", "module": "Admin Weekly Exports", "ward_id": null, "period_end": "2026-07-10", "authority_id": 15, "period_start": "2026-07-03", "summary_report_id": 32}	\N	2026-07-09 13:18:42.171879+03
15	\N	6	admin	admin_weekly_export_downloaded	\N	\N	\N	{"format": "csv", "module": "Admin Weekly Exports", "authority_id": 15, "summary_report_id": 32}	\N	2026-07-09 13:36:04.291983+03
16	7	9	authority	status_changed	pending	in-progress	Initial triage by officer	{"source": "status_logs"}	2	2026-07-09 13:37:39.881765+03
17	\N	6	admin	admin_weekly_export_downloaded	\N	\N	\N	{"format": "csv", "module": "Admin Weekly Exports", "authority_id": 15, "summary_report_id": 32}	\N	2026-07-09 13:46:13.933876+03
18	6	9	authority	status_changed	pending	in-progress	smoke-status-2026-07-09T10:54:43.887Z	{"source": "status_logs"}	3	2026-07-09 13:54:43.941953+03
19	6	9	authority	status_changed	in-progress	in-progress	smoke-note-2026-07-09T10:54:43.887Z	{"source": "status_logs"}	4	2026-07-09 13:54:44.002432+03
20	\N	6	admin	admin_weekly_export_generated	\N	\N	Generated CSV weekly export	{"format": "csv", "module": "Admin Weekly Exports", "ward_id": null, "period_end": "2026-07-10", "authority_id": 1, "period_start": "2026-07-03", "summary_report_id": 35}	\N	2026-07-09 13:54:44.19994+03
21	\N	6	admin	admin_weekly_export_downloaded	\N	\N	\N	{"format": "csv", "module": "Admin Weekly Exports", "authority_id": 1, "summary_report_id": 35}	\N	2026-07-09 13:54:44.213058+03
22	5	9	authority	status_changed	pending	in-progress	smoke-status-2026-07-09T11:02:36.559Z	{"source": "status_logs"}	5	2026-07-09 14:02:36.580212+03
23	5	9	authority	status_changed	in-progress	in-progress	smoke-note-2026-07-09T11:02:36.559Z	{"source": "status_logs"}	6	2026-07-09 14:02:36.635108+03
24	\N	6	admin	admin_weekly_export_generated	\N	\N	Generated CSV weekly export	{"format": "csv", "module": "Admin Weekly Exports", "ward_id": null, "period_end": "2026-07-10", "authority_id": 1, "period_start": "2026-07-03", "summary_report_id": 37}	\N	2026-07-09 14:02:36.8125+03
25	\N	6	admin	admin_weekly_export_downloaded	\N	\N	\N	{"format": "csv", "module": "Admin Weekly Exports", "authority_id": 1, "summary_report_id": 37}	\N	2026-07-09 14:02:36.823959+03
26	\N	6	admin	admin_weekly_export_downloaded	\N	\N	\N	{"format": "csv", "module": "Admin Weekly Exports", "authority_id": 1, "summary_report_id": 37}	\N	2026-07-09 15:33:40.841894+03
\.


--
-- Data for Name: authorities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authorities (id, name, type, jurisdiction, contact_email, phone, website, is_active, created_at, updated_at) FROM stdin;
1	Nairobi City County Government	county	Nairobi County	\N	\N	\N	t	2026-06-29 18:36:23.175052+03	2026-06-29 18:36:23.175052+03
2	Mombasa County Government	county	Mombasa County	info@mombasa.go.ke	+254 41 2311291	https://mombasa.go.ke	t	2026-06-29 18:51:46.009769+03	2026-06-29 18:51:46.009769+03
3	Kisumu County Government	county	Kisumu County	info@kisumu.go.ke	+254 57 2021025	https://kisumu.go.ke	t	2026-06-29 18:51:46.009769+03	2026-06-29 18:51:46.009769+03
10	Embakasi East Sub-County Office	municipal	Embakasi East, Nairobi	embakasi.east@nairobi.go.ke	+254 20 5579280	\N	t	2026-06-29 18:51:46.009769+03	2026-06-29 18:51:46.009769+03
11	Nairobi City County Government	county	Nairobi County	info@nairobi.go.ke	+254 20 2229000	https://nairobi.go.ke	t	2026-07-04 12:14:46.028534+03	2026-07-04 12:14:46.028534+03
12	Mombasa County Government	county	Mombasa County	info@mombasa.go.ke	+254 41 2311291	https://mombasa.go.ke	t	2026-07-04 12:14:46.028534+03	2026-07-04 12:14:46.028534+03
13	Kisumu County Government	county	Kisumu County	info@kisumu.go.ke	+254 57 2021025	https://kisumu.go.ke	t	2026-07-04 12:14:46.028534+03	2026-07-04 12:14:46.028534+03
14	Kenya National Highways Authority	national	Republic of Kenya	info@kenha.co.ke	+254 20 8013842	https://kenha.co.ke	t	2026-07-04 12:14:46.028534+03	2026-07-04 12:14:46.028534+03
15	Kenya Power & Lighting Company	national	Republic of Kenya	customercare@kplc.co.ke	+254 20 3201000	https://kplc.co.ke	t	2026-07-04 12:14:46.028534+03	2026-07-04 12:14:46.028534+03
16	Nairobi Water & Sewerage Company	municipal	Nairobi County	customercare@nairobiwater.co.ke	+254 20 3580000	https://nairobiwater.co.ke	t	2026-07-04 12:14:46.028534+03	2026-07-04 12:14:46.028534+03
17	Kenya Revenue Authority	national	Republic of Kenya	callcentre@kra.go.ke	+254 20 4999999	https://kra.go.ke	t	2026-07-04 12:14:46.028534+03	2026-07-04 12:14:46.028534+03
18	Habitat for Humanity Kenya	ngo	Multiple Counties	info@habitatkenya.org	+254 20 3870508	https://habitatkenya.org	t	2026-07-04 12:14:46.028534+03	2026-07-04 12:14:46.028534+03
19	Westlands Sub-County Office	municipal	Westlands, Nairobi	westlands@nairobi.go.ke	+254 20 4449950	\N	t	2026-07-04 12:14:46.028534+03	2026-07-04 12:14:46.028534+03
20	Embakasi East Sub-County Office	municipal	Embakasi East, Nairobi	embakasi.east@nairobi.go.ke	+254 20 5579280	\N	t	2026-07-04 12:14:46.028534+03	2026-07-04 12:14:46.028534+03
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description, created_at) FROM stdin;
1	Roads & Potholes	Potholes, road surface damage, blocked lanes, and unsafe road conditions.	2026-07-04 12:15:23.298651
2	Street Lighting	Broken, flickering, or missing public street lights.	2026-07-04 12:15:23.298651
3	Water Supply	Water outages, low pressure, leaks, burst pipes, and supply interruptions.	2026-07-04 12:15:23.298651
4	Drainage & Flooding	Blocked drains, flooding hotspots, storm-water overflow, and poor drainage.	2026-07-04 12:15:23.298651
5	Waste Management	Uncollected garbage, illegal dumping, overflowing bins, and waste accumulation.	2026-07-04 12:15:23.298651
6	Sanitation & Sewage	Sewage leaks, foul odors, blocked sewer lines, and sanitation hazards.	2026-07-04 12:15:23.298651
7	Public Safety	Unsafe public spaces, exposed hazards, and urgent community safety concerns.	2026-07-04 12:15:23.298651
8	Parks & Public Spaces	Damaged playgrounds, neglected parks, and broken public amenities.	2026-07-04 12:15:23.298651
9	Noise & Nuisance	Persistent loud noise, disruptive public nuisance, or disturbance complaints.	2026-07-04 12:15:23.298651
10	Other / General	General civic issues that do not clearly fit another category.	2026-07-04 12:15:23.298651
\.


--
-- Data for Name: category_authority_map; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category_authority_map (category_id, authority_id, created_at, response_deadline_days) FROM stdin;
1	15	2026-07-09 13:16:48.818881+03	7
1	1	2026-07-09 13:37:13.827213+03	7
2	1	2026-07-09 13:37:13.827213+03	7
3	1	2026-07-09 13:37:13.827213+03	7
4	1	2026-07-09 13:37:13.827213+03	7
5	1	2026-07-09 13:37:13.827213+03	7
6	1	2026-07-09 13:37:13.827213+03	7
7	1	2026-07-09 13:37:13.827213+03	7
8	1	2026-07-09 13:37:13.827213+03	7
9	1	2026-07-09 13:37:13.827213+03	7
10	1	2026-07-09 13:37:13.827213+03	7
\.


--
-- Data for Name: escalations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.escalations (id, report_id, authority_id, escalated_by, reason, status, authority_notes, is_overdue, escalated_at, acknowledged_at, resolved_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports (id, user_id, category_id, title, description, latitude, longitude, location_address, status, media_url, created_at, updated_at, tracking_number, ward_id, closed_by_admin, admin_override_notes, closed_at, resident_deleted_at, resident_deleted_by) FROM stdin;
1	8	4	leaking sewer 	leaking sewer that is in proximity to a transformer, which may explode when flooded 	-1.300387	36.822787	\N	pending	/uploads/report-1783159047724-568723669.jpeg	2026-07-04 12:57:27.759356	2026-07-04 13:25:04.958222	CP-20260704-26BA	42	f	\N	\N	2026-07-04 13:25:04.958222+03	8
2	10	2	Dangling flickering street lights	flickering lights that may cause potential fire or electric shck if not looked upon 	-1.322752	36.804306	\N	resolved	/uploads/report-1783177517558-926076402.jpg	2026-07-04 18:05:17.589842	2026-07-04 18:08:53.009183	CP-20260704-86BF	44	t	under review	2026-07-04 18:08:53.009183+03	\N	\N
3	8	1	erosion and destruction of terrain 	poor terrain that makes the land bare and may cause accidents 	-1.299630	36.821955	\N	pending	/uploads/report-1783578991064-855604242.jpeg	2026-07-09 09:36:31.097492	2026-07-09 09:37:03.936746	CP-20260709-764C	42	f	\N	\N	2026-07-09 09:37:03.936746+03	8
4	8	2	naked electric wires laying	naked wires that lay on the ground and spark may cause fires or harm to the general public 	-1.299610	36.821955	-1.299610, 36.821955	pending	\N	2026-07-09 09:41:27.050205	2026-07-09 09:41:50.885626	CP-20260709-9061	42	f	\N	\N	2026-07-09 09:41:50.885626+03	8
7	8	1	Collapsed Road Section Due to Erosion	A section of the road has been severely damaged by erosion, leaving the concrete slab unsupported and creating a dangerous drop-off. The damaged area poses a safety hazard to motorists and pedestrians and may worsen if left unattended. Immediate repair and reinforcement of the affected section are required to prevent accidents and restore safe access.	-1.299739	36.822030	-1.299739, 36.822030	in-progress	/uploads/report-1783581354768-308382349.jpeg	2026-07-09 10:15:54.820898	2026-07-09 13:37:39.881765	CP-20260709-0169	42	f	\N	\N	\N	\N
6	10	1	deep gulleys that pose threat during heavy rainfall	a big chunk of the road has been eroded and may pase life threatening dangers when the rains start	-1.299637	36.821988	-1.299637, 36.821988	in-progress	/uploads/report-1783579958457-659837031.jpeg	2026-07-09 09:52:38.486768	2026-07-09 13:54:43.941953	CP-20260709-6F8D	44	f	\N	\N	\N	\N
5	8	2	naked wires laying on the street 	naked wires laying on the street that may cause sparks and harm the general public 	-1.299651	36.822014	-1.299651, 36.822014	in-progress	/uploads/report-1783579433798-260209664.jpeg	2026-07-09 09:43:53.826494	2026-07-09 14:02:36.580212	CP-20260709-8D96	42	f	\N	\N	\N	\N
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, trigger_name, triggered_by, triggered_by_user_id, status, started_at, ended_at, records_processed, error_message) FROM stdin;
1	weekly-analytics	system	\N	completed	2026-07-06 06:00:00.349902+03	2026-07-06 06:00:00.49667+03	1	\N
\.


--
-- Data for Name: status_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status_logs (id, report_id, changed_by, old_status, new_status, notes, changed_at) FROM stdin;
1	2	6	pending	resolved	Admin override close: under review	2026-07-04 18:08:53.009183+03
2	7	9	pending	in-progress	Initial triage by officer	2026-07-09 13:37:39.881765+03
3	6	9	pending	in-progress	smoke-status-2026-07-09T10:54:43.887Z	2026-07-09 13:54:43.941953+03
4	6	9	in-progress	in-progress	smoke-note-2026-07-09T10:54:43.887Z	2026-07-09 13:54:44.002432+03
5	5	9	pending	in-progress	smoke-status-2026-07-09T11:02:36.559Z	2026-07-09 14:02:36.580212+03
6	5	9	in-progress	in-progress	smoke-note-2026-07-09T11:02:36.559Z	2026-07-09 14:02:36.635108+03
\.


--
-- Data for Name: summary_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.summary_reports (id, authority_id, ward_id, report_period, period_start, period_end, total_issues, open_issues, resolved_issues, pending_issues, escalated_issues, avg_resolution_days, top_category, report_notes, generated_at, report_file_url, report_file_type) FROM stdin;
12	15	\N	annual	2025-01-01	2025-12-31	890	95	700	85	10	9.80	Power Outages	Power outage issues. 79% resolved within 10 days avg.	2026-01-15 00:00:00+03	\N	\N
13	1	\N	monthly	2026-05-01	2026-05-31	215	44	148	18	5	12.40	Roads & Potholes	County-wide summary. Roads top category 3 months running.	2026-06-01 00:00:00+03	\N	\N
14	1	13	monthly	2026-05-01	2026-05-31	38	6	27	4	1	13.10	Roads & Potholes	KENHA resolved 3 major potholes mid-month.	2026-06-01 00:00:00+03	\N	\N
15	2	22	quarterly	2026-01-01	2026-03-31	74	9	55	7	3	16.20	Roads & Potholes	Coastal road degradation from rainfall.	2026-04-01 00:00:00+03	\N	\N
16	2	21	quarterly	2026-01-01	2026-03-31	88	12	61	9	6	18.70	Sanitation	Sewage overflow issues dominated Q1.	2026-04-01 00:00:00+03	\N	\N
17	1	16	monthly	2026-04-01	2026-04-30	19	3	14	2	0	9.80	Water Supply	Burst mains accounted for 60% of issues.	2026-05-01 00:00:00+03	\N	\N
18	1	13	monthly	2026-04-01	2026-04-30	42	8	28	4	2	14.50	Roads & Potholes	High pothole activity in Apr following rains.	2026-05-01 00:00:00+03	\N	\N
19	1	15	monthly	2026-04-01	2026-04-30	31	5	22	3	1	11.20	Waste Management	Illegal dumping spike near market.	2026-05-01 00:00:00+03	\N	\N
20	3	23	quarterly	2026-01-01	2026-03-31	56	8	40	6	2	15.00	Water Supply	Kondele water supply disruptions Q1.	2026-04-01 00:00:00+03	\N	\N
21	3	24	quarterly	2026-01-01	2026-03-31	48	7	35	5	1	13.50	Street Lighting	Street light outages main complaint.	2026-04-01 00:00:00+03	\N	\N
22	14	\N	annual	2025-01-01	2025-12-31	1240	110	980	120	30	22.30	Roads & Potholes	National roads summary 2025. 79% resolution rate.	2026-01-15 00:00:00+03	\N	\N
23	1	\N	monthly	2026-01-01	2026-12-31	0	0	0	0	0	0.00	\N	\N	2026-07-09 11:56:01.501454+03	\N	\N
24	1	\N	monthly	2026-01-01	2026-12-31	0	0	0	0	0	0.00	\N	\N	2026-07-09 11:56:03.167012+03	\N	\N
25	1	\N	monthly	2026-01-01	2026-12-31	0	0	0	0	0	0.00	\N	\N	2026-07-09 11:56:05.080551+03	\N	\N
26	1	\N	monthly	2026-01-01	2026-12-31	0	0	0	0	0	0.00	\N	\N	2026-07-09 11:56:06.880897+03	\N	\N
27	1	\N	weekly	2026-01-01	2026-12-31	0	0	0	0	0	0.00	\N	\N	2026-07-09 11:56:16.335975+03	\N	\N
31	1	15	weekly	2026-01-01	2026-12-31	0	0	0	0	0	0.00	\N	\N	2026-07-09 11:56:34.272415+03	\N	\N
32	15	\N	weekly	2026-07-03	2026-07-10	2	0	0	2	0	\N	Roads & Potholes	weekly_export:csv	2026-07-09 13:18:42.16357+03	/uploads/reports/weekly-report-a15-2026-07-03_2026-07-10-20260709101842.csv	csv
33	1	15	monthly	2026-01-01	2026-12-31	0	0	0	0	0	0.00	\N	\N	2026-07-09 13:19:39.171543+03	\N	\N
34	1	\N	monthly	2026-01-01	2026-12-31	4	2	1	1	0	0.08	Roads & Potholes	\N	2026-07-09 13:54:44.164058+03	\N	\N
35	1	\N	weekly	2026-07-03	2026-07-10	3	2	0	1	0	\N	Roads & Potholes	weekly_export:csv	2026-07-09 13:54:44.197968+03	/uploads/reports/weekly-report-a1-2026-07-03_2026-07-10-20260709105444.csv	csv
36	1	\N	monthly	2026-01-01	2026-12-31	4	3	1	0	0	0.12	Roads & Potholes	\N	2026-07-09 14:02:36.779036+03	\N	\N
37	1	\N	weekly	2026-07-03	2026-07-10	3	3	0	0	0	\N	Roads & Potholes	weekly_export:csv	2026-07-09 14:02:36.808729+03	/uploads/reports/weekly-report-a1-2026-07-03_2026-07-10-20260709110236.csv	csv
38	1	\N	monthly	2026-01-01	2026-12-31	4	3	1	0	0	0.12	Roads & Potholes	\N	2026-07-09 15:35:05.166521+03	\N	\N
\.


--
-- Data for Name: upvotes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.upvotes (user_id, report_id, created_at) FROM stdin;
8	1	2026-07-04 13:04:58.415099
10	2	2026-07-04 18:05:49.70432
8	6	2026-07-09 13:09:02.673943
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, password_hash, role, created_at, updated_at, ward_id, is_email_verified, email_verification_otp_hash, email_verification_otp_expires_at, email_verified_at, full_name, phone_number, date_of_birth, residence, profile_photo_url, bio, profile_edit_count, authority_id, is_active, last_login_at, deactivated_at, deactivation_reason) FROM stdin;
8	Obiero	obiero.odhiambo@strathmore.edu	$2b$12$cedrfHD.7OVqxGbZQBnhw.tg2Vmjrq1tocvphYi6A9uVc.BPG03NS	resident	2026-06-30 09:42:29.474532	2026-07-09 15:36:08.39147	42	t	\N	\N	2026-06-30 09:50:29.622482+03	Obiero	\N	\N	\N	\N	\N	0	\N	t	2026-07-09 15:36:08.39147+03	\N	\N
9	Owen	geniusowen768@gmail.com	$2b$12$1/QglLWfgUUCUZ35iBDM0usxGaSbofD5mbQGlJeOKWyHaD/IgEz5.	authority	2026-07-01 13:18:11.327075	2026-07-09 15:37:52.651056	\N	t	\N	\N	2026-07-01 13:19:16.509973+03	\N	\N	\N	\N	\N	\N	0	1	t	2026-07-09 15:37:52.651056+03	\N	\N
6	Samuel	anonymouslyluo@gmail.com	$2b$12$G/ryrp9/oSELqns58fy.3evVs6Td1rKeHNwSruYWwD14nb/FPTELa	admin	2026-06-29 19:08:08.546508	2026-07-09 15:42:06.553834	42	t	\N	\N	2026-06-29 19:48:21.871781+03	Samuel	0704122634	2005-01-01	upperhill	/uploads/profile-1783175485450-557882453.jpg	\N	2	\N	t	2026-07-09 15:42:06.553834+03	\N	\N
10	Muema 	muemalovine6@gmail.com	$2b$12$o8rL/nn8sGP5Ak/UJrMOPeM68IKy5zZUP/thHM7v/uTgVdBxLvfvW	resident	2026-07-04 17:46:39.823114	2026-07-09 09:49:35.139457	44	t	\N	\N	2026-07-04 17:56:30.461079+03	Muema	+254 755 828585	2006-02-14	Qwetu residence	/uploads/profile-1783177224683-318524149.jpg	\N	1	\N	t	2026-07-09 09:49:35.139457+03	\N	\N
\.


--
-- Data for Name: wards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wards (id, name, code, county, constituency, authority_id, latitude, longitude, population, is_active, created_at, updated_at) FROM stdin;
13	Westlands	NRB-001	Nairobi	Westlands	1	\N	\N	\N	t	2026-06-29 18:36:23.189604+03	2026-06-29 18:36:23.189604+03
15	Parklands	NRB-002	Nairobi	Westlands	1	-1.262100	36.819400	54000	t	2026-06-29 18:51:46.027371+03	2026-06-29 18:51:46.027371+03
16	Lavington	NRB-003	Nairobi	Dagoretti North	1	-1.285300	36.778100	47000	t	2026-06-29 18:51:46.027371+03	2026-06-29 18:51:46.027371+03
17	Karen	NRB-004	Nairobi	Langata	1	-1.330500	36.714700	39000	t	2026-06-29 18:51:46.027371+03	2026-06-29 18:51:46.027371+03
18	Embakasi Village	NRB-005	Nairobi	Embakasi East	1	-1.318200	36.896600	82000	t	2026-06-29 18:51:46.027371+03	2026-06-29 18:51:46.027371+03
19	Mihango	NRB-006	Nairobi	Embakasi East	10	-1.300400	36.924800	95000	t	2026-06-29 18:51:46.027371+03	2026-06-29 18:51:46.027371+03
20	Kilimani	NRB-007	Nairobi	Dagoretti North	1	-1.291900	36.784800	61000	t	2026-06-29 18:51:46.027371+03	2026-06-29 18:51:46.027371+03
21	Ganjoni	MSA-001	Mombasa	Mvita	2	-4.063700	39.665900	32000	t	2026-06-29 18:51:46.027371+03	2026-06-29 18:51:46.027371+03
22	Mvita	MSA-002	Mombasa	Mvita	2	-4.056100	39.658700	45000	t	2026-06-29 18:51:46.027371+03	2026-06-29 18:51:46.027371+03
23	Kondele	KSM-001	Kisumu	Kisumu Central	3	-0.100100	34.754100	56000	t	2026-06-29 18:51:46.027371+03	2026-06-29 18:51:46.027371+03
24	Kolwa Central	KSM-002	Kisumu	Kisumu East	3	-0.068700	34.799000	48000	t	2026-06-29 18:51:46.027371+03	2026-06-29 18:51:46.027371+03
25	Highrise	NRB-008	Nairobi	Mathare	1	-1.256600	36.852100	73000	t	2026-06-29 18:51:46.027371+03	2026-06-29 18:51:46.027371+03
26	Kitisuru	NBIW-001	Nairobi	Westlands	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
27	Parklands/Highridge	NBIW-002	Nairobi	Westlands	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
28	Karura	NBIW-003	Nairobi	Westlands	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
29	Kangemi	NBIW-004	Nairobi	Westlands	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
30	Mountain View	NBIW-005	Nairobi	Westlands	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
31	Kilimani	NBIW-006	Nairobi	Dagoretti North	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
32	Kawangware	NBIW-007	Nairobi	Dagoretti North	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
33	Gatina	NBIW-008	Nairobi	Dagoretti North	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
34	Kileleshwa	NBIW-009	Nairobi	Dagoretti North	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
35	Kabiro	NBIW-010	Nairobi	Dagoretti North	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
36	Mutu-ini	NBIW-011	Nairobi	Dagoretti South	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
37	Ngando	NBIW-012	Nairobi	Dagoretti South	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
38	Riruta	NBIW-013	Nairobi	Dagoretti South	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
39	Uthiru/Ruthimitu	NBIW-014	Nairobi	Dagoretti South	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
40	Waithaka	NBIW-015	Nairobi	Dagoretti South	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
41	Karen	NBIW-016	Nairobi	Lang'ata	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
42	Nairobi West	NBIW-017	Nairobi	Lang'ata	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
43	Mugumoini	NBIW-018	Nairobi	Lang'ata	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
44	South C	NBIW-019	Nairobi	Lang'ata	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
45	Nyayo Highrise	NBIW-020	Nairobi	Lang'ata	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
46	Laini Saba	NBIW-021	Nairobi	Kibra	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
47	Lindi	NBIW-022	Nairobi	Kibra	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
48	Makina	NBIW-023	Nairobi	Kibra	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
49	Woodley/Kenyatta Golf Course	NBIW-024	Nairobi	Kibra	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
50	Sarang'ombe	NBIW-025	Nairobi	Kibra	\N	\N	\N	\N	t	2026-06-29 18:58:51.88941+03	2026-06-29 18:58:51.88941+03
\.


--
-- Name: _migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._migrations_id_seq', 19, true);


--
-- Name: analytics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.analytics_id_seq', 1, true);


--
-- Name: audit_trail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_trail_id_seq', 26, true);


--
-- Name: authorities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.authorities_id_seq', 20, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_id_seq', 10, true);


--
-- Name: escalations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.escalations_id_seq', 1, false);


--
-- Name: reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_id_seq', 7, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sessions_id_seq', 1, true);


--
-- Name: status_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_logs_id_seq', 6, true);


--
-- Name: summary_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.summary_reports_id_seq', 38, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 10, true);


--
-- Name: wards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wards_id_seq', 62, true);


--
-- Name: _migrations _migrations_filename_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_filename_key UNIQUE (filename);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (id);


--
-- Name: analytics analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics
    ADD CONSTRAINT analytics_pkey PRIMARY KEY (id);


--
-- Name: audit_trail audit_trail_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_pkey PRIMARY KEY (id);


--
-- Name: audit_trail audit_trail_source_status_log_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_source_status_log_id_key UNIQUE (source_status_log_id);


--
-- Name: authorities authorities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authorities
    ADD CONSTRAINT authorities_pkey PRIMARY KEY (id);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: category_authority_map category_authority_map_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_authority_map
    ADD CONSTRAINT category_authority_map_pkey PRIMARY KEY (category_id, authority_id);


--
-- Name: escalations escalations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.escalations
    ADD CONSTRAINT escalations_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: reports reports_tracking_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_tracking_number_key UNIQUE (tracking_number);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: status_logs status_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_logs
    ADD CONSTRAINT status_logs_pkey PRIMARY KEY (id);


--
-- Name: summary_reports summary_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.summary_reports
    ADD CONSTRAINT summary_reports_pkey PRIMARY KEY (id);


--
-- Name: upvotes upvotes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.upvotes
    ADD CONSTRAINT upvotes_pkey PRIMARY KEY (user_id, report_id);


--
-- Name: analytics uq_analytics_period; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics
    ADD CONSTRAINT uq_analytics_period UNIQUE (period_start, period_end);


--
-- Name: summary_reports uq_summary_reports; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.summary_reports
    ADD CONSTRAINT uq_summary_reports UNIQUE (authority_id, ward_id, report_period, period_start);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: wards wards_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wards
    ADD CONSTRAINT wards_code_key UNIQUE (code);


--
-- Name: wards wards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wards
    ADD CONSTRAINT wards_pkey PRIMARY KEY (id);


--
-- Name: idx_analytics_generated_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_generated_at ON public.analytics USING btree (generated_at DESC);


--
-- Name: idx_analytics_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_period ON public.analytics USING btree (period_start DESC, period_end DESC);


--
-- Name: idx_audit_trail_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_trail_action ON public.audit_trail USING btree (action_type);


--
-- Name: idx_audit_trail_actor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_trail_actor ON public.audit_trail USING btree (actor_user_id);


--
-- Name: idx_audit_trail_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_trail_created_at ON public.audit_trail USING btree (created_at DESC);


--
-- Name: idx_audit_trail_report_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_trail_report_id ON public.audit_trail USING btree (report_id);


--
-- Name: idx_authorities_jurisdiction; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_authorities_jurisdiction ON public.authorities USING btree (jurisdiction);


--
-- Name: idx_authorities_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_authorities_type ON public.authorities USING btree (type);


--
-- Name: idx_cam_authority_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cam_authority_category ON public.category_authority_map USING btree (authority_id, category_id);


--
-- Name: idx_cam_response_deadline_days; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cam_response_deadline_days ON public.category_authority_map USING btree (response_deadline_days);


--
-- Name: idx_escalations_authority_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_escalations_authority_id ON public.escalations USING btree (authority_id);


--
-- Name: idx_escalations_escalated_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_escalations_escalated_by ON public.escalations USING btree (escalated_by);


--
-- Name: idx_escalations_is_overdue; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_escalations_is_overdue ON public.escalations USING btree (is_overdue);


--
-- Name: idx_escalations_report_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_escalations_report_id ON public.escalations USING btree (report_id);


--
-- Name: idx_escalations_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_escalations_status ON public.escalations USING btree (status);


--
-- Name: idx_reports_closed_by_admin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_closed_by_admin ON public.reports USING btree (closed_by_admin);


--
-- Name: idx_reports_resident_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_resident_deleted_at ON public.reports USING btree (resident_deleted_at);


--
-- Name: idx_reports_status_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_status_created_at ON public.reports USING btree (status, created_at DESC);


--
-- Name: idx_reports_user_visible_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_user_visible_created_at ON public.reports USING btree (user_id, created_at DESC) WHERE (resident_deleted_at IS NULL);


--
-- Name: idx_reports_ward_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_ward_id ON public.reports USING btree (ward_id);


--
-- Name: idx_sessions_started_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_started_at ON public.sessions USING btree (started_at DESC);


--
-- Name: idx_sessions_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_status ON public.sessions USING btree (status);


--
-- Name: idx_sessions_trigger_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_trigger_name ON public.sessions USING btree (trigger_name);


--
-- Name: idx_status_logs_changed_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_status_logs_changed_at ON public.status_logs USING btree (changed_at DESC);


--
-- Name: idx_status_logs_changed_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_status_logs_changed_by ON public.status_logs USING btree (changed_by);


--
-- Name: idx_status_logs_report_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_status_logs_report_id ON public.status_logs USING btree (report_id);


--
-- Name: idx_summary_reports_authority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_summary_reports_authority ON public.summary_reports USING btree (authority_id);


--
-- Name: idx_summary_reports_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_summary_reports_period ON public.summary_reports USING btree (report_period, period_start DESC);


--
-- Name: idx_summary_reports_ward; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_summary_reports_ward ON public.summary_reports USING btree (ward_id);


--
-- Name: idx_users_authority_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_authority_id ON public.users USING btree (authority_id);


--
-- Name: idx_users_email_verification_expires; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email_verification_expires ON public.users USING btree (email_verification_otp_expires_at);


--
-- Name: idx_users_last_login_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_last_login_at ON public.users USING btree (last_login_at DESC);


--
-- Name: idx_users_profile_edit_count; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_profile_edit_count ON public.users USING btree (profile_edit_count);


--
-- Name: idx_users_role_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_role_is_active ON public.users USING btree (role, is_active);


--
-- Name: idx_users_ward_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_ward_id ON public.users USING btree (ward_id);


--
-- Name: idx_wards_authority_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wards_authority_id ON public.wards USING btree (authority_id);


--
-- Name: idx_wards_county; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wards_county ON public.wards USING btree (county);


--
-- Name: status_logs no_delete_status_logs; Type: RULE; Schema: public; Owner: postgres
--

CREATE RULE no_delete_status_logs AS
    ON DELETE TO public.status_logs DO INSTEAD NOTHING;


--
-- Name: status_logs no_update_status_logs; Type: RULE; Schema: public; Owner: postgres
--

CREATE RULE no_update_status_logs AS
    ON UPDATE TO public.status_logs DO INSTEAD NOTHING;


--
-- Name: authorities trg_authorities_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_authorities_updated_at BEFORE UPDATE ON public.authorities FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: escalations trg_escalations_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_escalations_updated_at BEFORE UPDATE ON public.escalations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: status_logs trg_status_logs_to_audit_trail; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_status_logs_to_audit_trail AFTER INSERT ON public.status_logs FOR EACH ROW EXECUTE FUNCTION public.sync_status_logs_to_audit_trail();


--
-- Name: wards trg_wards_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_wards_updated_at BEFORE UPDATE ON public.wards FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: analytics analytics_generated_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics
    ADD CONSTRAINT analytics_generated_session_id_fkey FOREIGN KEY (generated_session_id) REFERENCES public.sessions(id) ON DELETE SET NULL;


--
-- Name: audit_trail audit_trail_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_trail audit_trail_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: audit_trail audit_trail_source_status_log_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_source_status_log_id_fkey FOREIGN KEY (source_status_log_id) REFERENCES public.status_logs(id) ON DELETE SET NULL;


--
-- Name: category_authority_map category_authority_map_authority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_authority_map
    ADD CONSTRAINT category_authority_map_authority_id_fkey FOREIGN KEY (authority_id) REFERENCES public.authorities(id) ON DELETE CASCADE;


--
-- Name: category_authority_map category_authority_map_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_authority_map
    ADD CONSTRAINT category_authority_map_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: escalations escalations_authority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.escalations
    ADD CONSTRAINT escalations_authority_id_fkey FOREIGN KEY (authority_id) REFERENCES public.authorities(id) ON DELETE RESTRICT;


--
-- Name: escalations escalations_escalated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.escalations
    ADD CONSTRAINT escalations_escalated_by_fkey FOREIGN KEY (escalated_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: escalations escalations_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.escalations
    ADD CONSTRAINT escalations_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: reports fk_reports_resident_deleted_by; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT fk_reports_resident_deleted_by FOREIGN KEY (resident_deleted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: users fk_users_authority_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_authority_id FOREIGN KEY (authority_id) REFERENCES public.authorities(id) ON DELETE SET NULL;


--
-- Name: reports reports_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE RESTRICT;


--
-- Name: reports reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reports reports_ward_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_ward_id_fkey FOREIGN KEY (ward_id) REFERENCES public.wards(id) ON DELETE SET NULL;


--
-- Name: sessions sessions_triggered_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_triggered_by_user_id_fkey FOREIGN KEY (triggered_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: status_logs status_logs_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_logs
    ADD CONSTRAINT status_logs_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: status_logs status_logs_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_logs
    ADD CONSTRAINT status_logs_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: summary_reports summary_reports_authority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.summary_reports
    ADD CONSTRAINT summary_reports_authority_id_fkey FOREIGN KEY (authority_id) REFERENCES public.authorities(id) ON DELETE CASCADE;


--
-- Name: summary_reports summary_reports_ward_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.summary_reports
    ADD CONSTRAINT summary_reports_ward_id_fkey FOREIGN KEY (ward_id) REFERENCES public.wards(id) ON DELETE SET NULL;


--
-- Name: upvotes upvotes_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.upvotes
    ADD CONSTRAINT upvotes_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: upvotes upvotes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.upvotes
    ADD CONSTRAINT upvotes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_ward_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_ward_id_fkey FOREIGN KEY (ward_id) REFERENCES public.wards(id) ON DELETE SET NULL;


--
-- Name: wards wards_authority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wards
    ADD CONSTRAINT wards_authority_id_fkey FOREIGN KEY (authority_id) REFERENCES public.authorities(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

